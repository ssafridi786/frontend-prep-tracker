// Global data and state
const roadmapData = {
    totalDays: 30,
    sections: [
        {
            id: "internet-web",
            title: "Internet & Web Fundamentals",
            days: "1-3",
            color: "#FF6B6B",
            topics: ["How internet works", "HTTP/HTTPS", "DNS", "Domain names", "Hosting", "Browser basics", "Developer tools"],
            sources: ["Scrimba fundamentals", "FreeCodeCamp"]
        },
        {
            id: "html",
            title: "HTML Mastery", 
            days: "4-7",
            color: "#4ECDC4",
            topics: ["HTML5 semantic elements", "Forms", "Accessibility (a11y)", "SEO basics", "Meta tags"],
            sources: ["Scrimba HTML course", "roadmap.sh HTML section"]
        },
        {
            id: "css",
            title: "CSS Expertise",
            days: "8-12", 
            color: "#45B7D1",
            topics: ["CSS Grid", "Flexbox", "Responsive design", "CSS preprocessors", "Animations", "BEM methodology"],
            sources: ["Scrimba CSS course", "Practice projects"]
        },
        {
            id: "javascript",
            title: "JavaScript Fundamentals",
            days: "13-18",
            color: "#F9CA24",
            topics: ["ES6+ features", "DOM manipulation", "Event handling", "Async/await", "Promises", "Fetch API", "Error handling"],
            sources: ["Scrimba JavaScript course", "LeetCode easy problems"]
        },
        {
            id: "react",
            title: "React Development", 
            days: "19-24",
            color: "#6C5CE7",
            topics: ["Components", "JSX", "Props", "State", "Hooks", "React Router", "Context API", "Testing basics"],
            sources: ["Scrimba React course", "Build 3 projects"]
        },
        {
            id: "tools",
            title: "Build Tools & Version Control",
            days: "25-27",
            color: "#A55EEA", 
            topics: ["Git/GitHub", "NPM/Yarn", "Webpack basics", "Package managers", "Module bundlers"],
            sources: ["Git practice", "Deploy projects"]
        },
        {
            id: "dsa-interview",
            title: "DSA & Interview Prep",
            days: "28-30",
            color: "#26DE81",
            topics: ["Arrays", "Objects", "Algorithms", "Problem solving", "Mock interviews", "System design basics"],
            sources: ["InstaByte.io problems", "LeetCode", "Preplaced methodology"]
        }
    ]
};

const timeSlots = [
    {"time": "5:30-9:00 AM", "duration": "3.5h", "focus": "Deep Learning", "description": "New concepts and theory"},
    {"time": "10:00 AM-1:00 PM", "duration": "3h", "focus": "Hands-on Practice", "description": "Coding and projects"}, 
    {"time": "2:00-5:00 PM", "duration": "3h", "focus": "Advanced Topics", "description": "Complex concepts and patterns"},
    {"time": "6:30-8:30 PM", "duration": "2h", "focus": "Interview Questions", "description": "Practice problems and review"},
    {"time": "10:00-11:30 PM", "duration": "1.5h", "focus": "Review & Planning", "description": "Consolidation and next day prep"},
    {"time": "11:00-11:30 PM", "duration": "0.5h", "focus": "Daily Reflection", "description": "Journal and habit tracking"}
];

const learningSources = [
    {"name": "Scrimba Pro", "url": "https://scrimba.com", "type": "course", "icon": "🎓"},
    {"name": "InstaByte.io", "url": "https://instabyte.io/p/interview-master-100", "type": "dsa", "icon": "💻"},
    {"name": "LeetCode", "url": "https://leetcode.com", "type": "coding", "icon": "🧮"},
    {"name": "roadmap.sh", "url": "https://roadmap.sh/frontend", "type": "roadmap", "icon": "🗺️"},
    {"name": "NotebookLM 1", "url": "https://notebooklm.google.com/notebook/2cffd828-7245-4544-be6f-e732828890f7", "type": "notes", "icon": "📚"},
    {"name": "NotebookLM 2", "url": "https://notebooklm.google.com/notebook/b8b5b308-9b6f-47dd-b3a3-cbcf1a48dff9", "type": "notes", "icon": "📚"},
    {"name": "FreeCodeCamp", "url": "https://freecodecamp.org", "type": "course", "icon": "🆓"},
    {"name": "HackerRank", "url": "https://hackerrank.com", "type": "coding", "icon": "⚡"},
    {"name": "VisuAlgo", "url": "https://visualgo.net", "type": "visualization", "icon": "📊"},
    {"name": "Algorithm Visualizer", "url": "https://algorithm-visualizer.org", "type": "visualization", "icon": "🎯"}
];

// Global state
let currentDay = 1;
let tasks = [];
let completedTopics = new Set();
let dailyProgress = {};
let streakData = [];
let reflections = {};
let editingTaskId = null;

// Initialize application
document.addEventListener('DOMContentLoaded', function() {
    loadFromStorage();
    initializeDisplay();
    setupEventListeners();
    renderRoadmapSections();
    renderSourceLinks();
    renderTimeSlots();
    populateSourceDropdowns();
    renderTaskTable();
    updateProgress();
    initializeCharts();
    initializeDefaultTasks();
});

// Storage functions
function saveToStorage() {
    const data = {
        currentDay,
        tasks,
        completedTopics: Array.from(completedTopics),
        dailyProgress,
        streakData,
        reflections,
        lastVisit: new Date().toISOString()
    };
    localStorage.setItem('frontendPrepDashboard', JSON.stringify(data));
}

function loadFromStorage() {
    const stored = localStorage.getItem('frontendPrepDashboard');
    if (stored) {
        const data = JSON.parse(stored);
        currentDay = data.currentDay || 1;
        tasks = data.tasks || [];
        completedTopics = new Set(data.completedTopics || []);
        dailyProgress = data.dailyProgress || {};
        streakData = data.streakData || [];
        reflections = data.reflections || {};
        
        // Check if it's a new day and update accordingly
        const lastVisit = new Date(data.lastVisit || new Date());
        const today = new Date();
        const daysDifference = Math.floor((today - lastVisit) / (1000 * 60 * 60 * 24));
        
        if (daysDifference > 0 && currentDay < 30) {
            // Update streak data for missed days
            for (let i = 0; i < daysDifference; i++) {
                streakData.push(false); // false indicates missed day
            }
        }
    }
}

// Display initialization
function initializeDisplay() {
    updateCurrentDate();
    updateCurrentDay();
    updateStreakDisplay();
    showCurrentSection();
}

function updateCurrentDate() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    };
    document.getElementById('currentDate').textContent = now.toLocaleDateString('en-US', options);
}

function updateCurrentDay() {
    document.getElementById('currentDay').textContent = currentDay;
    document.getElementById('todayDay').textContent = currentDay;
}

function getCurrentSection() {
    for (const section of roadmapData.sections) {
        const [start, end] = section.days.split('-').map(Number);
        if (currentDay >= start && currentDay <= end) {
            return section;
        }
    }
    return roadmapData.sections[0]; // fallback
}

function showCurrentSection() {
    const section = getCurrentSection();
    document.getElementById('sectionTitle').textContent = section.title;
    
    const topicsContainer = document.getElementById('sectionTopics');
    topicsContainer.innerHTML = '';
    
    section.topics.forEach((topic, index) => {
        const topicElement = document.createElement('div');
        topicElement.className = 'topic-item';
        topicElement.textContent = topic;
        
        const topicId = `${section.id}-${index}`;
        if (completedTopics.has(topicId)) {
            topicElement.classList.add('completed');
        }
        
        topicElement.addEventListener('click', () => toggleTopic(topicId, topicElement));
        topicsContainer.appendChild(topicElement);
    });
    
    updateSectionProgress();
}

function toggleTopic(topicId, element) {
    if (completedTopics.has(topicId)) {
        completedTopics.delete(topicId);
        element.classList.remove('completed');
    } else {
        completedTopics.add(topicId);
        element.classList.add('completed');
    }
    
    updateProgress();
    saveToStorage();
}

// Roadmap sections rendering
function renderRoadmapSections() {
    const container = document.getElementById('roadmapSections');
    container.innerHTML = '';
    
    roadmapData.sections.forEach(section => {
        const sectionElement = document.createElement('div');
        sectionElement.className = 'roadmap-section';
        sectionElement.style.borderLeftColor = section.color;
        
        const [start, end] = section.days.split('-').map(Number);
        if (currentDay >= start && currentDay <= end) {
            sectionElement.classList.add('active');
        }
        
        sectionElement.innerHTML = `
            <div class="section-info">
                <div class="section-name">${section.title}</div>
                <div class="section-days">Days ${section.days}</div>
            </div>
            <div class="section-progress-mini">
                <div class="progress-fill" style="width: ${getSectionProgress(section)}%; background: ${section.color}"></div>
            </div>
        `;
        
        sectionElement.addEventListener('click', () => jumpToSection(section));
        container.appendChild(sectionElement);
    });
}

function getSectionProgress(section) {
    const sectionTopics = section.topics.length;
    let completed = 0;
    
    section.topics.forEach((topic, index) => {
        const topicId = `${section.id}-${index}`;
        if (completedTopics.has(topicId)) {
            completed++;
        }
    });
    
    return sectionTopics > 0 ? Math.round((completed / sectionTopics) * 100) : 0;
}

function jumpToSection(section) {
    const [start] = section.days.split('-').map(Number);
    currentDay = start;
    updateCurrentDay();
    showCurrentSection();
    updateProgress();
    renderRoadmapSections();
    saveToStorage();
}

// Source links rendering
function renderSourceLinks() {
    const container = document.getElementById('sourceLinks');
    container.innerHTML = '';
    
    learningSources.forEach(source => {
        const linkElement = document.createElement('a');
        linkElement.className = 'source-link';
        linkElement.href = source.url;
        linkElement.target = '_blank';
        
        linkElement.innerHTML = `
            <span class="source-icon">${source.icon}</span>
            <span class="source-name">${source.name}</span>
        `;
        
        container.appendChild(linkElement);
    });
}

// Time slots rendering
function renderTimeSlots() {
    const container = document.getElementById('timeSlots');
    container.innerHTML = '';
    
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    
    timeSlots.forEach(slot => {
        const slotElement = document.createElement('div');
        slotElement.className = 'time-slot';
        
        // Check if current time falls within this slot
        const [startTime] = slot.time.split('-');
        const [startHour, startMinuteStr] = startTime.split(':');
        const startMinute = parseInt(startMinuteStr.split(' ')[0]);
        const isAM = startTime.includes('AM');
        
        let slotStartHour = parseInt(startHour);
        if (!isAM && slotStartHour !== 12) slotStartHour += 12;
        if (isAM && slotStartHour === 12) slotStartHour = 0;
        
        if (currentHour === slotStartHour || 
            (currentHour === slotStartHour && currentMinute >= startMinute)) {
            slotElement.classList.add('current');
        }
        
        slotElement.innerHTML = `
            <div class="slot-header">
                <div class="slot-time">${slot.time}</div>
                <div class="slot-duration">${slot.duration}</div>
            </div>
            <div class="slot-focus">${slot.focus}</div>
            <div class="slot-description">${slot.description}</div>
        `;
        
        container.appendChild(slotElement);
    });
}

// Populate dropdowns with source options
function populateSourceDropdowns() {
    // Populate task modal source dropdown
    const taskSource = document.getElementById('taskSource');
    taskSource.innerHTML = '<option value="">Select source</option>';
    learningSources.forEach(source => {
        const option = document.createElement('option');
        option.value = source.name;
        option.textContent = source.name;
        taskSource.appendChild(option);
    });
    
    // Populate filter source dropdown
    const sourceFilter = document.getElementById('sourceFilter');
    if (sourceFilter.children.length === 1) {
        learningSources.forEach(source => {
            const option = document.createElement('option');
            option.value = source.name;
            option.textContent = source.name;
            sourceFilter.appendChild(option);
        });
    }
}

// Task management
function renderTaskTable() {
    const tbody = document.getElementById('taskTableBody');
    tbody.innerHTML = '';
    
    const filteredTasks = getFilteredTasks();
    
    filteredTasks.forEach(task => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${task.name}</td>
            <td>${task.source}</td>
            <td>${task.dueDate}</td>
            <td><span class="task-priority ${task.priority}">${task.priority}</span></td>
            <td><span class="task-status ${task.status}">${task.status.replace('-', ' ')}</span></td>
            <td class="task-actions">
                <button class="btn btn--outline btn--sm" onclick="editTask('${task.id}')">Edit</button>
                <button class="btn btn--outline btn--sm" onclick="deleteTask('${task.id}')">Delete</button>
            </td>
        `;
        tbody.appendChild(row);
    });
    
    if (filteredTasks.length === 0) {
        const row = document.createElement('tr');
        row.innerHTML = '<td colspan="6" style="text-align: center; color: var(--color-text-secondary);">No tasks found</td>';
        tbody.appendChild(row);
    }
}

function getFilteredTasks() {
    const statusFilter = document.getElementById('statusFilter').value;
    const sourceFilter = document.getElementById('sourceFilter').value;
    
    return tasks.filter(task => {
        const statusMatch = statusFilter === 'all' || task.status === statusFilter;
        const sourceMatch = sourceFilter === 'all' || task.source === sourceFilter;
        return statusMatch && sourceMatch;
    });
}

function filterTasks() {
    renderTaskTable();
}

function addNewTask() {
    editingTaskId = null;
    document.getElementById('modalTitle').textContent = 'Add New Task';
    document.getElementById('saveTaskBtn').textContent = 'Save Task';
    
    // Clear form
    document.getElementById('taskName').value = '';
    document.getElementById('taskSource').value = '';
    document.getElementById('taskDueDate').value = '';
    document.getElementById('taskPriority').value = 'medium';
    document.getElementById('taskStatus').value = 'not-started';
    
    document.getElementById('taskModal').classList.add('active');
}

function editTask(taskId) {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;
    
    editingTaskId = taskId;
    document.getElementById('modalTitle').textContent = 'Edit Task';
    document.getElementById('saveTaskBtn').textContent = 'Update Task';
    
    document.getElementById('taskName').value = task.name;
    document.getElementById('taskSource').value = task.source;
    document.getElementById('taskDueDate').value = task.dueDate;
    document.getElementById('taskPriority').value = task.priority;
    document.getElementById('taskStatus').value = task.status;
    
    document.getElementById('taskModal').classList.add('active');
}

function deleteTask(taskId) {
    if (confirm('Are you sure you want to delete this task?')) {
        tasks = tasks.filter(t => t.id !== taskId);
        renderTaskTable();
        updateProgress();
        saveToStorage();
    }
}

function saveTask() {
    const name = document.getElementById('taskName').value.trim();
    const source = document.getElementById('taskSource').value;
    const dueDate = document.getElementById('taskDueDate').value;
    const priority = document.getElementById('taskPriority').value;
    const status = document.getElementById('taskStatus').value;
    
    if (!name || !source || !dueDate) {
        alert('Please fill in all required fields');
        return;
    }
    
    const task = {
        id: editingTaskId || generateId(),
        name,
        source,
        dueDate,
        priority,
        status,
        createdAt: editingTaskId ? tasks.find(t => t.id === editingTaskId).createdAt : new Date().toISOString()
    };
    
    if (editingTaskId) {
        const index = tasks.findIndex(t => t.id === editingTaskId);
        tasks[index] = task;
    } else {
        tasks.push(task);
    }
    
    closeTaskModal();
    renderTaskTable();
    updateProgress();
    saveToStorage();
}

function closeTaskModal() {
    document.getElementById('taskModal').classList.remove('active');
    editingTaskId = null;
}

function generateId() {
    return Date.now().toString(36) + Math.random().toString(36).substr(2);
}

// Progress tracking
function updateProgress() {
    const totalTopics = roadmapData.sections.reduce((sum, section) => sum + section.topics.length, 0);
    const completedCount = completedTopics.size;
    const overallPercentage = Math.round((completedCount / totalTopics) * 100);
    
    document.getElementById('overallProgress').style.width = `${overallPercentage}%`;
    document.getElementById('progressPercentage').textContent = `${overallPercentage}%`;
    
    // Update section progress
    const currentSection = getCurrentSection();
    const sectionPercentage = getSectionProgress(currentSection);
    const sectionProgressElement = document.getElementById('sectionProgress');
    if (sectionProgressElement) {
        sectionProgressElement.style.width = `${sectionPercentage}%`;
    }
    
    // Update daily progress
    dailyProgress[currentDay] = {
        topicsCompleted: completedCount,
        tasksCompleted: tasks.filter(t => t.status === 'completed').length,
        totalTasks: tasks.length,
        date: new Date().toISOString()
    };
    
    updateCharts();
}

function updateSectionProgress() {
    const currentSection = getCurrentSection();
    const sectionPercentage = getSectionProgress(currentSection);
    const sectionProgressElement = document.getElementById('sectionProgress');
    if (sectionProgressElement) {
        sectionProgressElement.style.width = `${sectionPercentage}%`;
    }
}

// Streak management
function updateStreakDisplay() {
    const streakCount = calculateCurrentStreak();
    document.getElementById('streakCount').textContent = streakCount;
    
    const chainContainer = document.getElementById('streakChain');
    chainContainer.innerHTML = '';
    
    // Show last 14 days of streak data
    const recentStreak = streakData.slice(-14);
    for (let i = 0; i < 14; i++) {
        const link = document.createElement('div');
        link.className = 'chain-link';
        if (i < recentStreak.length) {
            if (!recentStreak[i]) {
                link.classList.add('missed');
            }
        } else {
            // Future days - neutral color
            link.style.background = 'var(--color-border)';
        }
        chainContainer.appendChild(link);
    }
}

function calculateCurrentStreak() {
    let streak = 0;
    for (let i = streakData.length - 1; i >= 0; i--) {
        if (streakData[i]) {
            streak++;
        } else {
            break;
        }
    }
    return streak;
}

function markDayComplete() {
    const currentReflection = reflections[currentDay];
    if (!currentReflection || (!currentReflection.learning && !currentReflection.challenges && !currentReflection.goals)) {
        alert('Please complete your daily reflection first!');
        return;
    }
    
    // Ensure streakData array is long enough
    while (streakData.length < currentDay) {
        streakData.push(false);
    }
    
    streakData[currentDay - 1] = true;
    updateStreakDisplay();
    
    if (currentDay < 30) {
        currentDay++;
        updateCurrentDay();
        showCurrentSection();
        renderRoadmapSections();
    }
    
    saveToStorage();
    alert('Day marked as complete! Great job! 🎉');
}

// Reflection functionality
function setupEventListeners() {
    // Rating stars
    const stars = document.querySelectorAll('.star');
    stars.forEach(star => {
        star.addEventListener('click', function() {
            const rating = parseInt(this.dataset.rating);
            updateStarRating(rating);
        });
    });
    
    // Close modal when clicking outside
    document.getElementById('taskModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeTaskModal();
        }
    });
}

function updateStarRating(rating) {
    const stars = document.querySelectorAll('.star');
    stars.forEach((star, index) => {
        if (index < rating) {
            star.classList.add('active');
        } else {
            star.classList.remove('active');
        }
    });
}

function saveReflection() {
    const learning = document.getElementById('todayLearning').value.trim();
    const challenges = document.getElementById('todayChallenges').value.trim();
    const goals = document.getElementById('tomorrowGoals').value.trim();
    const rating = document.querySelectorAll('.star.active').length;
    
    if (!learning && !challenges && !goals) {
        alert('Please fill in at least one reflection field');
        return;
    }
    
    reflections[currentDay] = {
        learning,
        challenges,
        goals,
        rating,
        date: new Date().toISOString()
    };
    
    saveToStorage();
    alert('Reflection saved successfully! 💭');
}

// Chart functionality
let progressChart = null;
let dailyChart = null;

function initializeCharts() {
    const progressCtx = document.getElementById('progressChart').getContext('2d');
    const dailyCtx = document.getElementById('dailyChart').getContext('2d');
    
    // Progress by section chart
    progressChart = new Chart(progressCtx, {
        type: 'doughnut',
        data: {
            labels: roadmapData.sections.map(s => s.title),
            datasets: [{
                data: roadmapData.sections.map(s => getSectionProgress(s)),
                backgroundColor: roadmapData.sections.map(s => s.color),
                borderWidth: 2,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Progress by Section'
                },
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
    
    // Daily progress chart
    const dailyData = Array.from({length: 30}, (_, i) => {
        const day = i + 1;
        return dailyProgress[day]?.topicsCompleted || 0;
    });
    
    dailyChart = new Chart(dailyCtx, {
        type: 'line',
        data: {
            labels: Array.from({length: 30}, (_, i) => `Day ${i + 1}`),
            datasets: [{
                label: 'Topics Completed',
                data: dailyData,
                borderColor: '#1FB8CD',
                backgroundColor: 'rgba(31, 184, 205, 0.1)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Daily Progress Trend'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

function updateCharts() {
    if (progressChart) {
        progressChart.data.datasets[0].data = roadmapData.sections.map(s => getSectionProgress(s));
        progressChart.update();
    }
    
    if (dailyChart) {
        const dailyData = Array.from({length: 30}, (_, i) => {
            const day = i + 1;
            return dailyProgress[day]?.topicsCompleted || 0;
        });
        dailyChart.data.datasets[0].data = dailyData;
        dailyChart.update();
    }
}

// CSV Export functionality
function exportWeeklyCSV() {
    const currentWeekStart = Math.floor((currentDay - 1) / 7) * 7 + 1;
    const currentWeekEnd = Math.min(currentWeekStart + 6, 30);
    
    const csvContent = generateWeeklyCSV(currentWeekStart, currentWeekEnd);
    downloadCSV(csvContent, `week-${Math.ceil(currentDay / 7)}-progress.csv`);
}

function generateWeeklyCSV(startDay, endDay) {
    let csv = 'Day,Section,Topics Completed,Tasks Completed,Productivity Rating,Learning Notes\n';
    
    for (let day = startDay; day <= endDay; day++) {
        const section = roadmapData.sections.find(s => {
            const [start, end] = s.days.split('-').map(Number);
            return day >= start && day <= end;
        });
        
        const progress = dailyProgress[day] || {};
        const reflection = reflections[day] || {};
        
        csv += `Day ${day},"${section?.title || 'N/A'}",${progress.topicsCompleted || 0},${progress.tasksCompleted || 0},${reflection.rating || 0},"${(reflection.learning || '').replace(/"/g, '""')}"\n`;
    }
    
    return csv;
}

function downloadCSV(content, filename) {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', filename);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}

// Initialize default tasks
function initializeDefaultTasks() {
    if (tasks.length === 0) {
        const defaultTasks = [
            {
                id: generateId(),
                name: 'Complete HTML Fundamentals Course',
                source: 'Scrimba Pro',
                dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                priority: 'high',
                status: 'not-started',
                createdAt: new Date().toISOString()
            },
            {
                id: generateId(),
                name: 'Solve 10 Easy LeetCode Problems',
                source: 'LeetCode',
                dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                priority: 'medium',
                status: 'not-started',
                createdAt: new Date().toISOString()
            },
            {
                id: generateId(),
                name: 'Read Frontend Roadmap',
                source: 'roadmap.sh',
                dueDate: new Date().toISOString().split('T')[0],
                priority: 'low',
                status: 'completed',
                createdAt: new Date().toISOString()
            }
        ];
        
        tasks = defaultTasks;
        renderTaskTable();
        saveToStorage();
    }
}

// Auto-save functionality
setInterval(() => {
    saveToStorage();
}, 30000); // Auto-save every 30 seconds